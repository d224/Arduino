# Regress tests

```testmain.py``` runs MQTT/UDP implementations in pairs
testing protocol implementation compatibility. Currently
it tests java/lua/python/c implementations against each other.

