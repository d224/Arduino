/**
 * 
 * 
 * <p>Extremely simple MQTT-based protocol over an UDP broadcast transport.</p>
 *
 * <p>See https://github.com/dzavalishin/mqtt_udp</p>
 * 
 * @author dz@dz.ru
 *
 * 
 *
 */
package ru.dz.mqtt_udp;