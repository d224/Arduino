/**
 * 
 * <p>Protocol implementation details</p>
 * 
 * @author dz
 *
 */
package ru.dz.mqtt_udp.proto;