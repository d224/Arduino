#!/bin/sh
#./setup.py sdist upload
python ./setup.py sdist upload -r https://upload.pypi.org/legacy/
