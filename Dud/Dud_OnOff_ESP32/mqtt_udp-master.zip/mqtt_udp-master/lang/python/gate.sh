#!/bin/sh
cd examples
python bidirectional_gate.py &
