package ru.dz.mqtt_udp.clock


/**
 * Must send regular messages with time update.
 */ 
class Clock {
    val TOPIC = "\$SYS/clock";
}
