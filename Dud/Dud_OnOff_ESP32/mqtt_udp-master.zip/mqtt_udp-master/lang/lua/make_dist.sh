#!/bin/sh
tar --mode 666 -czf lua_mqttudp-0.5-0.tar.gz mqttudp/*

