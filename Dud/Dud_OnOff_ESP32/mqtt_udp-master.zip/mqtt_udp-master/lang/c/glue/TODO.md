*      millisecond timing for cygwin
*      millisecond timing for mingw
