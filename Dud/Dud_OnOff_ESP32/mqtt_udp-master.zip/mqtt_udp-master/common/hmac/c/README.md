# HMAC - digital signature

Based on code from <https://github.com/mygityf/cipher>

key = "key" 6B657900
text = "text"

## MD5 based HMAC

my D0CA6177C61C975FD2F8C07D8C6528C6
ok d0ca6177c61c975fd2f8c07d8c6528c6


## SHA-256 based HMAC


my 6AFA9046A9579CAD143A384C1B564B9A250D27D6F6A63F9F20BF3A7594C9E2C6
ok 6afa9046a9579cad143a384c1b564b9a250d27d6f6a63f9f20bf3a7594c9e2c6


