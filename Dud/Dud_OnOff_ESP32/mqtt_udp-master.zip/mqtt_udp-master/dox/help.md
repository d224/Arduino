# RST help and reference pages

<http://www.sphinx-doc.org/en/master/usage/restructuredtext/basics.html>

<http://docutils.sourceforge.net/docs/ref/rst/directives.html>

<https://www.ericholscher.com/blog/2016/jul/1/sphinx-and-rtd-for-writers/>

<https://draft-edx-style-guide.readthedocs.io/en/latest/ExampleRSTFile.html>

<https://media.readthedocs.org/pdf/brandons-sphinx-tutorial/latest/brandons-sphinx-tutorial.pdf>

<http://mt2007-cat.ru/catnip/index.html>
