#!/bin/sh
sphinx-build source build
