## Bug or feature


## What is wrong / not implemented


## How should it be


## Correct behaviour is documented in (URL)


## Environment

*   GitHub commit:
*   Prog language:
*   OS/hardware:


## Fixed/implemented in

-   [ ] Pyhon implementation
-   [ ] Java implementation
-   [ ] Java tools
-   [ ] C implementation/Unix
-   [ ] C implementation/Embedded
-   [ ] Lua implementation
-   [ ] CodeSys implementation


