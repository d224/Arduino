# MQTT/UDP GUI tool to view traffic, get and set topic data

See [help page in Wiki](https://github.com/dzavalishin/mqtt_udp/wiki/MQTT-UDP-Viewer-Help)

